"""
Routes module initialization
"""
