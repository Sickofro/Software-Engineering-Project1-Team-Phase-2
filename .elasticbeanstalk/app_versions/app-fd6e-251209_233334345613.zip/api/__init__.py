"""
API module for ECE 461 Phase 2
Trustworthy Model Registry REST API
"""
