# Software package initializer
# Allows `import Software` in tests and other modules
__version__ = "0.1.0"
