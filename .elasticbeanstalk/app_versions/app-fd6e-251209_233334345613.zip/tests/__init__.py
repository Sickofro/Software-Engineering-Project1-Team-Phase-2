# tests package init
